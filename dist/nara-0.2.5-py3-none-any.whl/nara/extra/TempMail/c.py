# [1,2,7,8,2,1,7,8,0]
# find the number that comes only one time, without using inbuild count function
# write code for this


