
from time import time as t

C =t()
import nara
print(f"imported nara in {t()-C} seconds")